<?php include sfException::getTemplatePathForError('xml', false) ?>

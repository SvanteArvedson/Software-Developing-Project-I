/*
  <?php echo $code.' '.$text."\n" ?>
*/

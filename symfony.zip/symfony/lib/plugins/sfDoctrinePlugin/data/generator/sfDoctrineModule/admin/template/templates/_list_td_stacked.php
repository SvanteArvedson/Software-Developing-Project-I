<td colspan="<?php echo count($this->configuration->getValue('list.display'))  ?>">
  [?php echo <?php echo $this->getI18NString('list.params') ?> ?]
</td>

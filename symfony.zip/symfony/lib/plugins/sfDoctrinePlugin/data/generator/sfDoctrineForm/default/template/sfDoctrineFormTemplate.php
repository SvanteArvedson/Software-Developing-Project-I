[?php

/**
 * <?php echo $this->table->getOption('name') ?> form.
 *
 * @package    form
 * @subpackage <?php echo $this->table->getOption('name') ?>

 * @version    SVN: $Id: sfDoctrineFormTemplate.php 6174 2007-11-27 06:22:40Z fabien $
 */
class <?php echo $this->table->getOption('name') ?>Form extends Base<?php echo $this->table->getOption('name') ?>Form
{
  public function configure()
  {
  }
}
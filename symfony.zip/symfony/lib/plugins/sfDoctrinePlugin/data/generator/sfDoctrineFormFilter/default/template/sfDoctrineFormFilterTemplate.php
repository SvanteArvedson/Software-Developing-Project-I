[?php

/**
 * <?php echo $this->table->getOption('name') ?> filter form.
 *
 * @package    filters
 * @subpackage <?php echo $this->table->getOption('name') ?>
 *
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 11675 2008-09-19 15:21:38Z fabien $
 */
class <?php echo $this->table->getOption('name') ?>FormFilter extends Base<?php echo $this->table->getOption('name') ?>FormFilter
{
  public function configure()
  {
  }
}
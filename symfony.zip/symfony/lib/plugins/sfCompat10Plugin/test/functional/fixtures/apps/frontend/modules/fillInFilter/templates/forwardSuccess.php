<?php echo form_tag('#') ?>
  <?php echo input_tag('name') ?>
  <?php echo submit_tag('save') ?>
</form>

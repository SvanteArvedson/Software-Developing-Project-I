Chapter 5 - Configuring Symfony
===============================

To be simple and easy to use, symfony defines a few conventions, which should satisfy the most common requirements of standard applications without need for modification. However, using a set of simple and powerful configuration files, it is possible to customize almost everything about the way the framework and your application interact with each other. With these files, you will also be able to add specific parameters for your applications.

This chapter explains how the configuration system works:

  * The symfony configuration is kept in files written in YAML, although you can always choose another format.
  * Configuration files are at the project, application, and module levels in a project's directory structure.
  * You can define several sets of configuration settings; in symfony, a set of configuration is called an environment.
  * The values defined in the configuration files are available from the PHP code of your application.
  * Additionally, symfony authorizes PHP code in YAML files and other tricks to make the configuration system even more flexible.

The Configuration System
------------------------

Regardless of purpose, most web applications share a common set of characteristics. For instance, some sections can be restricted to a subset of users, or the pages can be decorated by a layout, or a form can be filled with the user input after a failed validation. A framework defines a structure for emulating these characteristics, and the developer can further tweak them by changing a configuration setting. This strategy saves a lot of development time, since many changes don't require a single line of code, even if there is a lot of code behind. It is also much more efficient, because it ensures such information can be maintained in a single and easily identifiable location.

However, this approach has two serious drawbacks:

  * Developers end up writing endlessly complex XML files.
  * In a PHP architecture, every request takes much longer to process.

Taking these disadvantages into account, symfony uses configuration files only for what they are best at doing. As a matter of fact, the ambition of the configuration system in symfony is to be:

  * Powerful: Almost every aspect that can be managed using configuration files is managed using configuration files.
  * Simple: Many aspects of configuration are not shown in a normal application, since they seldom need to be changed.
  * Easy: Configuration files are easy to read, to modify, and to create by the developer.
  * Customizable: The default configuration language is YAML, but it can be INI, XML, or whatever format the developer prefers.
  * Fast: The configuration files are never processed by the application but by the configuration system, which compiles them into a fast-processing chunk of code for the PHP server.

### YAML Syntax and Symfony Conventions

For its configuration, symfony uses the YAML format by default, instead of more traditional INI or XML formats. YAML shows structure through indentation and is fast to write. Its advantages and basic rules were already described in Chapter 1. However, you need to keep a few conventions in mind when writing YAML files. This section introduces several of the most prominent conventions. For a complete dissertation on the topic, visit the YAML website ([http://www.yaml.org/](http://www.yaml.org/)).

First of all, never use tabs in YAML files; use spaces instead. YAML parsers can't understand files with tabs, so indent your lines with spaces (a double blank is the symfony convention for indentation), as shown in Listing 5-1.

Listing 5-1 - YAML Files Forbid Tabs

    # Never use tabs
    all:
    -> mail:
    -> -> webmaster:  webmaster@example.com

    # Use blanks instead
    all:
      mail:
        webmaster: webmaster@example.com

If your parameters are strings starting or ending with spaces, 
contain special characters (such as the "octothorpe" (#) or comma),
or key words such as "no, false, off" (where a string is intended) you must
enclose the value in single quotes, as shown in Listing 5-2.

Listing 5-2 - Nonstandard Strings Should Be Enclosed in Single Quotes

    error1: This field is compulsory
    error2: '  This field is compulsory  '
    error3: 'Don''t leave this field blank'   # Single quotes must be doubled
    error4: 'Enter a # symbol to define an extension number'
    i18n:   'no' # if we left off the quotes here, a boolean false would be returned

You can define long strings in multiple lines, and also multiple-line strings, with the special string headers (> and |) plus an additional indentation. Listing 5-3 demonstrates this convention.

Listing 5-3 - Defining Long and Multiline Strings

    # Folded style, introduced by >
    # Each line break is folded to a space
    # Makes YAML more readable
    accomplishment: >
      Mark set a major league
      home run record in 1998.

    # Literal style, introduced by |
    # All line breaks count
    # Indentation doesn't appear in the resulting string
    stats: |
      65 Home Runs
      0.278 Batting Average

To define a value as an array, enclose the elements in square brackets or use the expanded syntax with dashes, as shown in Listing 5-4.

Listing 5-4 - YAML Array Syntax

    # Shorthand syntax for arrays
    players: [ Mark McGwire, Sammy Sosa, Ken Griffey ]

    # Expanded syntax for arrays
    players:
      - Mark McGwire
      - Sammy Sosa
      - Ken Griffey

To define a value as an associative array, or hash, enclose the elements in 
curly brackets and always insert a spaces between the key and the value in the
`key: value` pair, and any list items separated by commas. You can also use the
expanded syntax by adding indentation and a carriage return for every new key,
as shown in Listing 5-5.

Listing 5-5 - YAML Associative Array Syntax

    # Incorrect syntax, blanks are missing after the colons and comma
    mail: {webmaster:webmaster@example.com,contact:contact@example.com}

    # Correct shorthand syntax for associative arrays
    mail: { webmaster: webmaster@example.com, contact: contact@example.com }

    # Expanded syntax for associative arrays
    mail:
      webmaster: webmaster@example.com
      contact:   contact@example.com

To give a Boolean value, you can choose from a number of representations.
Listing 5-6 shows the complete listing of values that will be converted to
boolean by the parser, provided they are not enclosed in quotes.

Listing 5-6 - YAML Boolean Values Syntax

    true_values:   [ on, true, +, yes, y ]
    false_values:  [ off, false, -, no, n ]

>**NOTE**
>The above values are supported by the YAML parser, however it is highly
>recommended to use only true or false to be compliant with current and
>future YAML specifications.

Don't hesitate to add comments (starting with the hash mark, `#`) and extra
spaces to values to make your YAML files more readable, as shown in Listing 5-7.

Listing 5-7 - YAML Comments Syntax and Value Alignment

    # This is a comment line
    mail:
      webmaster: webmaster@example.com
      contact:   contact@example.com
      admin:     admin@example.com   # extra spaces allow nice alignment of values

In some symfony configuration files, you will sometimes see lines that start with a hash mark (and, as such, ignored by the YAML parsers) but look like usual settings lines. This is a symfony convention: the default configuration, inherited from other YAML files located in the symfony core, is repeated in commented lines in your application configuration, for your information. If you want to change the value of such a parameter, you need to uncomment the line first, as shown in Listing 5-8.

Listing 5-8 - Default Configuration Is Shown Commented

    # The cache is off by default
    settings:
    # cache: off

    # If you want to change this setting, uncomment the line first
    settings:
      cache: on

Symfony sometimes groups the parameter definitions into categories. All settings of a given category appear indented under the category header. Structuring long lists of `key: value` pairs by grouping them into categories improves the readability of the configuration. Category headers start with a dot (`.`). Listing 5-9 shows an example of categories.

Listing 5-9 - Category Headers Look Like Keys, But Start with a Dot

    all:
      .general:
        tax:        19.6

      mail:
        webmaster:  webmaster@example.com

In this example, `mail` is a key and `general` is only a category header. Everything works as if the category header didn't exist, as shown in Listing 5-10. The `tax` parameter is actually a direct child of the `all` key. However using categories helps symfony dealing with arrays that are beneath the `all` key.

Listing 5-10 - Category Headers Are Only There for Readability and Are Actually Ignored

    all:
      tax:          19.6

      mail:
        webmaster:  webmaster@example.com

>**SIDEBAR**
>And if you don't like YAML
>
>YAML is just an interface to define settings to be used by PHP code, so the configuration defined in YAML files ends up being transformed into PHP. After browsing an application, check its cached configuration (in `cache/frontend/dev/config/`, for instance). You will see the PHP files corresponding to your YAML configuration. You will learn more about the configuration cache later in this chapter.
>
>The good news is that if you don't want to use YAML files, you can still do what the configuration files do by hand, in PHP or via another format (XML, INI, and so on). Throughout this book, you will meet alternative ways to define configuration without YAML, and you will even learn to replace the symfony configuration handlers (in Chapter 19). If you use them wisely, these tricks will enable you to bypass configuration files or define your own configuration format.

### Help, a YAML File Killed My App!

The YAML files are parsed into PHP hashes and arrays, and then the values are used in various parts of the application to modify the behavior of the view, the controller, or the model. Many times, when there is a problem in a YAML file, it is not detected until the value actually needs to be used. Moreover, the error or exception that is thrown then is usually not clearly related to the YAML configuration file.

If your application suddenly stops working after a configuration change, you should check that you didn't make any of the common mistakes of the inattentive YAML coder:

  * You miss a space between a key and its value:

        key1:value1      # A space is missing after the :

  * Keys in a sequence are not indented the same way:

        all:
          key1:  value1
           key2: value2  # Indentation is not the same as the other sequence members
          key3:  value3

  * There is a reserved YAML character in a key or a value, without string delimiters:

        message: tell him: go way    # :, [, ], { and } are reserved in YAML
        message: 'tell him: go way'  # Correct syntax

  * You are modifying a commented line:

        # key: value     # Will never be taken into account due to the leading #

  * You set values with the same key name twice at the same level:

        key1: value1
        key2: value2
        key1: value3     # key1 is defined twice, the value is the last one defined

  * You think that the setting takes a special type, while it is always a string, until you convert it:

        income: 12,345   # Until you convert it, this is still a string

Overview of the Configuration Files
-----------------------------------

Configuration is distributed into files, by subject. The files contain parameter definitions, or settings. Some of these parameters can be overridden at several levels (project, application, and module); some are specific to a certain level. The next chapters will deal with the configuration files related to their main topic, and Chapter 19 will deal with advanced configuration.

### Project Configuration

There are a few project configuration files by default. Here are the files that can be found in the `myproject/config/` directory:

  * `ProjectConfiguration.class.php`: This is the very first file included by any request or command. It contains the path to the framework files, and you can change it to use a different installation. See Chapter 19 for advanced usage of this file.
  * `databases.yml`: This is where you define the access and connection settings to the database (host, login, password, database name, and so on). Chapter 8 will tell you more about it. It can also be overridden at the application level.
  * `properties.ini`: This file holds a few parameters used by the command line tool, including the project name and the connection settings for distant servers. See Chapter 16 for an overview of the features using this file.
  * `rsync_exclude.txt`: This file specifies which directories must be excluded from the synchronization between servers. It is discussed in Chapter 16.
  * `schema.yml` and `propel.ini`: These are data access configuration files used by Propel (symfony's ORM layer). They are used to make the Propel libraries work with the symfony classes and the data of your project. `schema.yml` contains a representation of the project's relational data model. `propel.ini` is automatically generated, so you probably do not need to modify it. If you don't use Propel, these files are not needed. Chapter 8 will tell you more about their use.

These files are mostly used by external components or by the command line, or they need to be processed even before any YAML parsing program can be loaded by the framework. That's why some of them don't use the YAML format.

### Application Configuration

The main part of the configuration is the application configuration. It is defined in the front controller (in the `web/` directory) for the main configuration, in YAML files located in the application `config/` directory, in `i18n/` directories for the internationalization files, and in the framework files for invisible--although useful--additional application configuration.

#### Front Controller Configuration

The very first application configuration is actually found in the front controller; that is the very first script executed by a request. Take a look at the default `web/index.php` in Listing 5-11.

Listing 5-11 - The Default Production Front Controller

    [php]
    <?php

    require_once(dirname(__FILE__).'/../config/ProjectConfiguration.class.php');

    $configuration = ProjectConfiguration::getApplicationConfiguration('frontend', 'prod', false);
    sfContext::createInstance($configuration)->dispatch();

After defining the name of the application (`frontend`) and the environment (`prod`), the application configuration is called before creating a context and dispatching. So a few useful methods are available in the application configuration class:

  * `$configuration->getRootDir()`: Project root directory (normally, should remain at its default value, unless you change the file structure).
  * `$configuration->getApplication()`: Application name in the project. Necessary to compute file paths.
  * `$configuration->getEnvironment()`: Environment name (`prod`, `dev`, or any other project-specific environment that you define). Will determine which configuration settings are to be used. Environments are explained later in this chapter.
  * `$configuration->isDebug()`: Activation of the debug mode (see Chapter 16 for details).

If you want to change one of these values, you probably need an additional front controller. The next chapter will tell you more about front controllers and how to create a new one.

#### Main Application Configuration

The main application configuration is stored in files located in the `myproject/apps/frontend/config/` directory:

  * `app.yml`: This file should contain the application-specific configuration; that is, global variables defining business or applicative logic specific to an application, which don't need to be stored in a database. Tax rates, shipping fares, and e-mail addresses are often stored in this file. It is empty by default.
  * `frontendConfiguration.class.php`: This class bootstraps the application, which means that it does all the very basic initializations to allow the application to start. This is where you can customize your directory structure or add application-specific constants (Chapter 19 provides more details). It inherits from the `sfApplicationConfiguration` class.
  * `factories.yml`: Symfony defines its own class to handle the view, the request, the response, the session, and so on. If you want to use your own classes instead, this is where you can specify them. Chapter 17 provides more information.
  * `filters.yml`: Filters are portions of code executed for every request. This file is where you define which filters are to be processed, and it can be overridden for each module. Chapter 6 discusses filters in more detail.
  * `routing.yml`: The routing rules, which allow transforming unreadable and unbookmarkable URLs into "smart" and explicit ones, are stored in this file. For new applications, a few default rules exist. Chapter 9 is all about links and routing.
  * `settings.yml`: The main settings of a symfony application are defined in this file. This is where you specify if your application has internationalization, its default language, the request timeout and whether caching is turned on. With a one-line change in this file, you can shut down the application so you can perform maintenance or upgrade one of its components. The common settings and their use are described in Chapter 19.
  * `view.yml`: The structure of the default view (name of the layout, default style sheets and JavaScript files to be included, default content-type, and so on) is set in this file. Chapter 7 will tell you more about this file. These settings can be overridden for each module.

#### Internationalization Configuration

Internationalized applications can display pages in several languages. This requires specific configuration. There are two configuration places for internationalization:

  * The `factories.yml` of the application `config/` directory: This file defines the i18n factory and general translation options, such as the default culture for the translation, whether the translations come from files or a database, and their format.
  * Translation files in the application `i18n/` directory: These are basically dictionaries, giving a translation for each of the phrases used in the application templates so that the pages show translated text when the user switches language.

Note that the activation of the i18n features is set in the `settings.yml` file. You will find more information about these features in Chapter 13.

#### Additional Application Configuration

A second set of configuration files is in the symfony installation directory (in `sfConfig::get('sf_symfony_lib_dir')/config/config/`) and doesn't appear in the configuration directory of your applications. The settings defined there are defaults that seldom need to be modified, or that are global to all projects. However, if you need to modify them, just create an empty file with the same name in your `myproject/apps/frontend/config/` directory, and override the settings you want to change. The settings defined in an application always have precedence over the ones defined in the framework. The following are the configuration files in the symfony installation config/ directory:

  * `autoload.yml`: This file contains the settings of the autoloading feature. This feature exempts you from requiring custom classes in your code if they are located in specific directories. It is described in detail in Chapter 19.
  * `core_compile.yml` and `bootstrap_compile.yml`: These are lists of classes to be included to start an application (in `bootstrap_compile.yml`) and to process a request (in `core_compile.yml`). These classes are actually concatenated into an optimized PHP file without comments, which will accelerate the execution by minimizing the file access operations (one file is loaded instead of more than forty for each request). This is especially useful if you don't use a PHP accelerator. Optimization techniques are described in Chapter 18.
  * `config_handlers.yml`: This is where you can add or modify the handlers used to process each configuration file. Chapter 19 provides more details.

### Module Configuration

By default, a module has no specific configuration. But, if required, you can override some application-level settings for a given module. For instance, you might do this to include a specific JavaScript file for all actions of a module. You can also choose to add new parameters restricted to a specific module to preserve encapsulation.

As you may have guessed, module configuration files must be located in a `myproject/apps/frontend/modules/mymodule/config/` directory. These files are as follows:

  * `generator.yml`: For modules generated according to a database table (scaffoldings and administrations), this file defines how the interface displays rows and fields, and which interactions are proposed to the user (filters, sorting, buttons, and so on). Chapter 14 will tell you more about it.
  * `module.yml`: This file contains custom parameters specific to a module (equivalent to the `app.yml`, but at the module level) and action configuration. Chapter 6 provides more details.
  * `security.yml`: This file sets access restrictions for actions. This is where you specify that a page can be viewed only by registered users or by a subset of registered users with special permissions. Chapter 6 will tell you more about it.
  * `view.yml`: This file contains configuration for the views of one or all of the actions of a module. It overrides the application `view.yml` and is described in Chapter 7.

Most module configuration files offer the ability to define parameters for all the views or all the actions of a module, or for a subset of them.

>**SIDEBAR**
>Too many files?
>
>You might be overwhelmed by the number of configuration files present in the application. But please keep the following in mind:
>
>Most of the time, you don't need to change the configuration, since the default conventions match the most common requirements. Each configuration file is related to a particular feature, and the next chapters will detail their use one by one. When you focus on a single file, you can see clearly what it does and how it is organized. For professional web development, the default configuration is often not completely adapted. The configuration files allow for an easy modification of the symfony mechanisms without code. Imagine the amount of PHP code necessary to achieve the same amount of control. If all the configuration were located in one file, not only would the file be completely unreadable, but you could not redefine configuration at several levels (see the "Configuration Cascade" section later in this chapter).
>
>The configuration system is one of the great strengths of symfony, because it makes symfony usable for almost every kind of web application, and not only for the ones for which the framework was originally designed.

Environments
------------

During the course of application development, you will probably need to keep several sets of configuration in parallel. For instance, you will need to have the connection settings for your tests database available during development, and the ones for your real data available for production. To answer the need of concurrent configurations, symfony offers different environments.

### What Is an Environment?

An application can run in various environments. The different environments share the same PHP code (apart from the front controller), but can have completely different configurations. For each application, symfony provides three default environments: production (`prod`), test (test), and development (dev). You're also free to add as many custom environments as you wish.

So basically, environments and configuration are synonyms. For instance, a test environment will log alerts and errors, while a `prod` environment will only log errors. Cache acceleration is often deactivated in the `dev` environment, but activated in the `test` and `prod` environments. The `dev` and `test` environments may need test data, stored in a database distinct from the one used in the production environment. So the database configuration will be different between the two environments. All environments can live together on the same machine, although a production server generally contains only the `prod` environment.

In the `dev` environment, the logging and debugging settings are all enabled, since maintenance is more important than performance. On the contrary, the prod environment has settings optimized for performance by default, so the production configuration turns off many features. A good rule of thumb is to navigate in the development environment until you are satisfied with the feature you are working on, and then switch to the production environment to check its speed.

The `test` environment differs from the `dev` and `prod` environment in other ways. You interact with this environment solely through the command line for the purpose of functional testing and batch scripting. Consequently, the `test` environment is close to the production one, but it is not accessed through a web browser. It simulates the use of cookies and other HTTP specific components.

To change the environment in which you're browsing your application, just change the front controller. Until now, you have seen only the development environment, since the URLs used in the example called the development front controller:

    http://localhost/frontend_dev.php/mymodule/index

However, if you want to see how the application reacts in production, call the production front controller instead:

    http://localhost/index.php/mymodule/index

If your web server has mod_rewrite enabled, you can even use the custom symfony rewriting rules, written in `web/.htaccess`. They define the production front controller as the default execution script and allow for URLs like this:

    http://localhost/mymodule/index

>**SIDEBAR**
>Environments and Servers
>
>Don't mix up the notions of environment and server. In symfony, different environments are different configurations, and correspond to a front controller (the script that executes the request). Different servers correspond to different domain names in the URL.
>
>     http://localhost/frontend_dev.php/mymodule/index
>            _________ _______________
>             server     environment
>
>Usually, developers work on applications in a development server, disconnected from the Internet and where all the server and PHP configuration can be changed at will. When the time comes for releasing the application to production, the application files are transferred to the production server and made accessible to the end users.
>
>This means that many environments are available on each server. For instance, you can run in the production environment even on your development server. However, most of the time, only the production environment should be accessible in the production server, to avoid public visibility of server configuration and security risks. To prevent accidental exposure of the non-production controllers on the production system, symfony adds a basic IP check to these front controllers, which will allow access only from localhost. If you want to have them accessible you can remove that, but think about the risk of having this accessible by anyone, as malicious users could guess the default `frontend_dev.php` and get access to a lot of debug information.
>
>To add a new environment, you don't need to create a directory or to use the symfony CLI. Simply create a new front controller and change the environment name definition in it. This environment inherits all the default configuration plus the settings that are common to all environments. The next chapter will show you how to do this.

### Configuration Cascade

The same setting can be defined more than once, in different places. For instance, you may want to set the mime-type of your pages to `text/html` for all of the application, except for the pages of an `rss` module, which will need a `text/xml` mime-type. Symfony gives you the ability to write the first setting in `frontend/config/view.yml` and the second in `frontend/modules/rss/config/view.yml`. The configuration system knows that a setting defined at the module level must override a setting defined at the application level.

In fact, there are several configuration levels in symfony:

  * Granularity levels:
    * The default configuration located in the framework
    * The global configuration for the whole project (in `myproject/config/`)
    * The local configuration for an application of the project (in `myproject/apps/frontend/config/`)
    * The local configuration restricted to a module (in `myproject/apps/frontend/modules/mymodule/config/`)
  * Environment levels:
    * Specific to one environment
    * For all environments

Of all the properties that can be customized, many are environment-dependent. Consequently, many YAML configuration files are divided by environment, plus a tail section for all environments. The result is that typical symfony configuration looks like Listing 5-12.

Listing 5-12 - The Structure of Symfony Configuration Files

    # Production environment settings
    prod:
      ...

    # Development environment settings
    dev:
      ...

    # Test environment settings
    test:
      ...

    # Custom environment settings
    myenv:
      ...

    # Settings for all environments
    all:
      ...

In addition, the framework itself defines default values in files that are not located in the project tree structure, but in the `sfConfig::get('sf_symfony_lib_dir')/config/config/` directory of your symfony installation. The default configuration is set in these files as shown in Listing 5-13. These settings are inherited by all applications.

Listing 5-13 - The Default Configuration, in `sfConfig::get('sf_symfony_lib_dir')/config/config/settings.yml`

     # Default settings:
     default:
       default_module:         default
       default_action:         index
       ...

These default definitions are repeated in the project, application, and module configuration files as comments, as shown in Listing 5-14, so that you know that some parameters are defined by default and that they can be modified.

Listing 5-14 - The Default Configuration, Repeated for Information, in `frontend/config/settings.yml`

    #all:
    #  default_module:         default
    #  default_action:         index
    #...

This means that a property can be defined several times, and the actual value results from a definition cascade. A parameter definition in a named environment has precedence over the same parameter definition for all environments, which has precedence over a definition in the default configuration. A parameter definition at the module level has precedence over the same parameter definition at the application level, which has precedence over a definition at the project level. This can be wrapped up in the following priority list:

  1. Module
  2. Application
  3. Project
  4. Specific environment
  5. All environments
  6. Default

The Configuration Cache
-----------------------

Parsing YAML and dealing with the configuration cascade at runtime represent a significant overhead for each request. Symfony has a built-in configuration cache mechanism designed to speed up requests.

The configuration files, whatever their format, are processed by some special classes, called handlers, that transform them into fast-processing PHP code. In the development environment, the handlers check the configuration for changes at each request, to promote interactivity. They parse the recently modified files so that you can see a change in a YAML file immediately. But in the production environment, the processing occurs once during the first request, and then the processed PHP code is stored in the cache for subsequent requests. The performance is guaranteed, since every request in production will just execute some well-optimized PHP code.

For instance, if the `app.yml` file contains this:

    all:                   # Setting for all environments
      mail:
        webmaster:         webmaster@example.com

then the file `config_app.yml.php`, located in the `cache/` folder of your project, will contain this:

    [php]
    <?php

    sfConfig::add(array(
      'app_mail_webmaster' => 'webmaster@example.com',
    ));

As a consequence, most of the time, the YAML files aren't even parsed by the framework, which relies on the configuration cache instead. However, in the development environment, symfony will systematically compare the dates of modification of the YAML files and the cached files, and reprocess only the ones that have changed since the previous request.

This presents a major advantage over many PHP frameworks, where configuration files are compiled at every request, even in production. Unlike Java, PHP doesn't share an execution context between requests. For other PHP frameworks, keeping the flexibility of XML configuration files requires a major performance hit to process all the configuration at every request. This is not the case in symfony. Thanks to the cache system, the overhead caused by configuration is very low.

There is an important consequence of this mechanism. If you change the configuration in the production environment, you need to force the reparsing of all the configuration files for your modification to be taken into account. For that, you just need to clear the cache, either by deleting the content of the cache/ directory or, more easily, by calling the `cache:clear` task:

    > php symfony cache:clear

Accessing the Configuration from Code
-------------------------------------

All the configuration files are eventually transformed into PHP, and many of the settings they contain are automatically used by the framework, without further intervention. However, you sometimes need to access some of the settings defined in the configuration files from your code (in actions, templates, custom classes, and so on). The settings defined in `settings.yml`, `app.yml`, and `module.yml` are available through a special class called `sfConfig`.

### The sfConfig Class

You can access settings from within the application code through the `sfConfig` class. It is a registry for configuration parameters, with a simple getter class method, accessible from every part of the code:

    [php]
    // Retrieve a setting
    $parameter = sfConfig::get('param_name', $default_value);

Note that you can also define, or override, a setting from within PHP code:

    [php]
    // Define a setting
    sfConfig::set('param_name', $value);

The parameter name is the concatenation of several elements, separated by underscores, in this order:

  * A prefix related to the configuration file name (`sf_` for `settings.yml`, `app_` for `app.yml`, `mod_` for `module.yml`)
  * The parent keys (if defined), in lowercase
  * The name of the key, in lowercase

The environment is not included, since your PHP code will have access only to the values defined for the environment in which it's executed.

For instance, if you need to access the values defined in the `app.yml` file shown in Listing 5-15, you will need the code shown in Listing 5-16.

Listing 5-15 - Sample `app.yml` Configuration

    all:
      .general:
        tax:          19.6
      default_user:
        name:         John Doe
      mail:
        webmaster:    webmaster@example.com
        contact:      contact@example.com
    dev:
      mail:
        webmaster:    dummy@example.com
        contact:      dummy@example.com

Listing 5-16 - Accessing Configuration Settings in PHP in the `dev` Environment

    [php]
    echo sfConfig::get('app_tax');   // Remember that category headers are ignored
     => '19.6'
    echo sfConfig::get('app_default_user_name');
     => 'John Doe'
    echo sfConfig::get('app_mail_webmaster');
     => 'dummy@example.com'
    echo sfConfig::get('app_mail_contact');
     => 'dummy@example.com'

So symfony configuration settings have all the advantages of PHP constants, but without the disadvantages, since the value can be changed.

On that account, the `settings.yml` file, where you can set the framework settings for an application, is the equivalent to a list of `sfConfig::set()` calls. Listing 5-17 is interpreted as shown in Listing 5-18.

Listing 5-17 - Extract of `settings.yml`

    all:
      .settings:
        csrf_secret:       false
        escaping_strategy: off 
        escaping_method:   ESC_SPECIALCHARS

Listing 5-18 - What Symfony Does When Parsing `settings.yml`

    [php]
    sfConfig::add(array(
      'sf_csrf_secret' => 'false',
      'sf_escaping_strategy' => 'false',
      'sf_escaping_method' => 'ESC_SPECIALCHARS',
    ));

Refer to Chapter 19 for the meanings of the settings found in the `settings.yml` file.

### Custom Application Settings and `app.yml`

Most of the settings related to the features of an application should be stored in the `app.yml` file, located in the `myproject/apps/frontend/config/` directory. This file is environment-dependent and empty by default. Put in every setting that you want to be easily changed, and use the `sfConfig` class to access these settings from your code. Listing 5-19 shows an example.

Listing 5-19 - Sample `app.yml` to Define Credit Card Operators Accepted for a Given Site

    all:
      creditcards:
        fake:             off
        visa:             on
        americanexpress:  on

    dev:
      creditcards:
        fake:             on

To know if the `fake` credit cards are accepted in the current environment, get the value of:

    [php]
    sfConfig::get('app_creditcards_fake');

>**NOTE**
>When you should require an PHP array directly beneath the `all` key you need to use a category header, otherwise symfony will make the values separately available as shown above.
>
>     all:
>       .array:
>         creditcards:
>           fake:             off
>           visa:             on
>           americanexpress:  on
>
>     [php]
>     print_r(sfConfig::get('app_creditcards'));
>
>     Array(
>       [fake] => false
>       [visa] => true
>       [americanexpress] => true
>     )

>**TIP**
>Each time you are tempted to define a constant or a setting in one of your scripts, think about if it would be better located in the `app.yml` file. This is a very convenient place to store all application settings.

When your need for custom parameters becomes hard to handle with the `app.yml` syntax, you may need to define a syntax of your own. In that case, you can store the configuration in a new file, interpreted by a new configuration handler. Refer to Chapter 19 for more information about configuration handlers.

Tips for Getting More from Configuration Files
----------------------------------------------

There are a few last tricks to learn before writing your own YAML files. They will allow you to avoid configuration duplication and to deal with your own YAML formats.

### Using Constants in YAML Configuration Files

Some configuration settings rely on the value of other settings. To avoid setting the same value twice, symfony supports constants in YAML files. On encountering a setting name (one that can be accessed by `sfConfig::get()`) in capital letters enclosed in `%` signs, the configuration handlers replace them with their current value. See Listing 5-20 for an example.

Listing 5-20 - Using Constants in YAML Files, Example from `autoload.yml`

    autoload:
      symfony:
        name:           symfony
        path:           %SF_SYMFONY_LIB_DIR%
        recursive:      on
        exclude:        [vendor]

The path parameter will take the value returned by `sfConfig::get('sf_symfony_lib_dir')`. If you want one configuration file to rely on another, you need to make sure that the file you rely on is already parsed (look in the symfony source to find out the order in which the configuration files are parsed). `app.yml` is one of the last files parsed, so you may rely on others in it.

### Using Scriptable Configuration

It may happen that your configuration relies on external parameters (such as a database or another configuration file). To deal with these particular cases, the symfony configuration files are parsed as PHP files before being passed to the YAML parser. It means that you can put PHP code in YAML files, as in Listing 5-21.

Listing 5-21 - YAML Files Can Contain PHP

    all:
      translation:
        format:  <?php echo (sfConfig::get('sf_i18n') == true ? 'xliff' : 'none')."\n" ?>

But be aware that the configuration is parsed very early in the life of a request, so you will not have any symfony built-in methods or functions to help you.

Also, as the `echo` language construct does not add a carriage return by default, you need to add a "\n" or use the `echoln` helper to keep the YAML format valid.

    all:
      translation:
        format:  <?php echoln(sfConfig::get('sf_i18n') == true ? 'xliff' : 'none') ?>

>**CAUTION**
>In the production environment, the configuration is cached, so the configuration files are parsed (and executed) only once after the cache is cleared.

### Browsing Your Own YAML File

Whenever you want to read a YAML file directly, you can use the `sfYaml` class. It is a YAML parser that can turn a YAML file into a PHP associative array. Listing 5-22 presents a sample YAML file, and Listing 5-23 shows you how to parse it.

Listing 5-22 - Sample `test.yml` File

    house:
      family:
        name:     Doe
        parents:  [John, Jane]
        children: [Paul, Mark, Simone]
      address:
        number:   34
        street:   Main Street
        city:     Nowheretown
        zipcode:  12345

Listing 5-23 - Using the `sfYaml` Class to Turn a YAML File into an Associative Array

    [php]
    $test = sfYaml::load('/path/to/test.yml');
    print_r($test);

    Array(
      [house] => Array(
        [family] => Array(
          [name] => Doe
          [parents] => Array(
            [0] => John
            [1] => Jane
          )
          [children] => Array(
            [0] => Paul
            [1] => Mark
            [2] => Simone
          )
        )
        [address] => Array(
          [number] => 34
          [street] => Main Street
          [city] => Nowheretown
          [zipcode] => 12345
        )
      )
    )

Summary
-------

The symfony configuration system uses the YAML language to be simple and readable. The ability to deal with multiple environments and to set parameters through a definition cascade offers versatility to the developer. Some of the configuration can be accessed from within the code via the `sfConfig` object, especially the application settings stored in the `app.yml` file.

Yes, symfony does have a lot of configuration files, but this approach makes it more adaptable. Remember that you don't need to bother with them unless your application requires a high level of customization.
